# 3D Earthquake Visualizer

An interactive 3D globe that plots every magnitude 4.0+ earthquake from the
last five years (~80,000 events, USGS data) at its true geographic location and
real depth below the surface. It groups quakes into spatio-temporal clusters,
draws the sequence of each aftershock series, and lets you scrub through time to
watch seismicity unfold.

**Live demo:** https://danielflopez1.github.io/3D-Earthquakes/

Built with [Three.js](https://threejs.org/) and native ES modules — no build
step, no dependencies to install. It runs as static files.

---

## What you're looking at

Each earthquake is a sphere placed on (or below) the globe:

| Visual encoding | Meaning |
| --- | --- |
| **Sphere position** | Real latitude / longitude |
| **Depth below the surface** | Real focal depth, scaled to the Earth's 6371 km radius |
| **Sphere size** | Magnitude |
| **Sphere color** | Recency — red (newest) → green (oldest) |
| **Lines between quakes** | A local sequence (one cluster), colored blue (recent) → purple (older) |
| **Vertical lines** | Depth lines dropping each quake to its surface point |

The globe itself is semi-transparent so you can see quakes on the far side and
those that sit deep inside the mantle.

---

## How to use it

### Camera
- **Drag** to rotate the globe
- **Scroll** to zoom (zooms toward the cursor)
- **Double-click** a quake or the globe to set the orbit focus point there

### Controls (top-right: time · bottom-right: display)

**Time window**
- **From / To sliders** — restrict the visible range to a slice of the 5 years
- **▶ Play** — time-lapse: sweeps the *To* edge forward so quakes appear in the
  order they happened. The **speed** slider sets the pace.

**Display**
- **Globe** — globe opacity (turn it down to see interior structure)
- **Quakes** — overall sphere size multiplier
- **Orbit** — a jog-wheel: drag it to swing the camera around the focus point to
  a new diagonal, then release to recenter. Pair it with double-click-to-focus
  for a close-up turntable on any cluster.
- **Depth lines** — toggle the vertical drop-lines
- **Mainshock focus** — dim the swarm and highlight the largest event in each
  cluster, so the mainshock/aftershock structure stands out
- **Direction arrows** — chevrons along each sequence showing the migration
  direction of the rupture over time

### Inspecting a quake
- **Hover** a sphere for a tooltip (magnitude, place, depth, time)
- **Click** a sphere to open the detail panel. It shows the event and a
  **cross-section** of its whole cluster — depth plotted against distance along
  the cluster's principal axis (a side view that reveals fault dip or
  subduction geometry).

---

## How it works

### Data pipeline
On load, `usgs.js` queries the [USGS FDSN event API](https://earthquake.usgs.gov/fdsnws/event/1/)
for M4+ events over the last 5 years as CSV. USGS rejects any single query that
would return more than 20,000 rows, and M4+ over 5 years is ~80k — so the
fetcher **bisects the time window** recursively (halves run in parallel) until
each slice fits under the cap, then merges the pieces. Results are stored in
`localStorage`; on later visits it does a **delta fetch** (only events since the
last cached time) and merges them in, so repeat loads are fast and light.

### Clustering
`clustering.js` runs **ST-DBSCAN** (spatio-temporal DBSCAN): two quakes are
neighbors if they're within ~300 km *and* ~90 days of each other (great-circle
distance via the haversine formula). A naive all-pairs scan is O(n²) — fatal at
80k events — so neighbors are found with a **spatio-temporal hash grid** (cells
of ~epsKm in lat/lon and ~epsDays in time, with longitude widened toward the
poles and wrapped across the antimeridian). The grid only prunes the candidate
set; the exact distance/time tests still decide every edge, so results are
identical to brute force. Dense groups become clusters; isolated events are
marked as noise. Each cluster is what gets drawn as a connected sequence.

### Rendering
`quakeLayer.js` builds the scene geometry. All quakes render as a single
**`InstancedMesh`** — one draw call for the whole catalog, with per-instance
position, size, and color — which is what makes 80k spheres run at full frame
rate. A raycast hit reports an `instanceId` that maps straight back to the
quake. Depth lines, sequence polylines, and direction chevrons are likewise
merged into single `LineSegments` objects with per-vertex colors. Depth is
proportional to the real Earth radius, and the globe uses an ocean alpha mask so
transparency reads correctly from any angle.

### Project structure
No bundler — the browser loads ES modules directly, which is also why it deploys
to GitHub Pages unchanged.

```
index.html        markup + import map + entry <script type="module">
styles.css        all UI styling
src/
  main.js         entry point — wires modules together, kicks off the load
  config.js       tunable constants (magnitude floor, cluster radius, URLs…)
  state.js        shared mutable app state
  geo.js          lat/lon/depth → 3D vector, haversine distance
  colors.js       recency + sequence color ramps
  clustering.js   ST-DBSCAN spatio-temporal clustering
  usgs.js         load order: cache → baked snapshot → live USGS, + delta top-up
  scene.js        renderer, camera, controls, earth, starfield, focus/orbit
  quakeLayer.js   quake spheres, depth lines, sequences, arrows, visual modes
  interaction.js  hover tooltip, click detail, cross-section, focus
  ui.js           panel / slider / toggle / playback wiring
scripts/
  fetch-quakes.mjs        Node build-time USGS fetch → data/quakes.csv
.github/workflows/
  update-data.yml         hourly cron: rebuild snapshot + deploy to Pages
```

The module graph has no cycles: `config` and `state` are leaves, everything
flows up to `main`. DOM access lives only in `ui.js` and `interaction.js`,
keeping the render layer DOM-free.

---

## Running locally

The app is static files, but ES modules require a server (opening `index.html`
via `file://` won't work). Any static server does:

```bash
# Python
python -m http.server 8123

# or Node
npx serve
```

Then open `http://localhost:8123`.

---

## Deploying (auto-updating)

The site deploys to **GitHub Pages via GitHub Actions**, and the earthquake data
refreshes itself **hourly** — no manual steps after the one-time setup.

How it works (`.github/workflows/update-data.yml`):

1. On an hourly `cron` (and on every push to `main`), the workflow runs
   `scripts/fetch-quakes.mjs`, which does the same time-bisected USGS fetch and
   writes a slim snapshot to `data/quakes.csv`.
2. It bundles the code + that snapshot and deploys them straight to Pages as an
   artifact. **The data is never committed** — the repo stays code-only, so its
   history doesn't bloat with a 15 MB file changing every hour.
3. Visitors load `data/quakes.csv` (one fast CDN fetch, ~1h stale at most), then
   the client delta-fetches only the handful of events since — so the map is
   current to the minute on every load.

One-time setup:

- **Settings → Pages → Source: GitHub Actions** (instead of "Deploy from a
  branch"). After that, pushing code still deploys, and the hourly job keeps the
  data fresh on its own.

Notes:

- The repo must be **public** for unlimited free Actions minutes (each run is
  ~1–2 min). GitHub auto-pauses scheduled workflows after 60 days of repo
  inactivity — any push resumes them.
- If `data/quakes.csv` is absent (e.g. a plain local checkout), the client
  transparently falls back to fetching live from USGS.

Tuning knobs (magnitude floor, year range, cluster thresholds) live in
`src/config.js`; the refresh interval is the `cron` line in the workflow.

---

## Data source

Earthquake data from the U.S. Geological Survey
[Earthquake Hazards Program](https://earthquake.usgs.gov/). USGS data is in the
public domain.
